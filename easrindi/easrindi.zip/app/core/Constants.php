<?php

define("BASE_URL", 'http://localhost/easrindi/public');

define("DB_HOST", "localhost");
define("DB_NAME", "eas_final");
define("DB_USERNAME", "eas");
define("DB_PASSWORD", "eas123");